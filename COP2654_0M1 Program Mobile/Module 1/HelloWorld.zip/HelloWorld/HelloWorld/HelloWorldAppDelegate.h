//
//  HelloWorldAppDelegate.h
//  HelloWorld
//
//  Created by Hansul Hudson Jr on 8/26/13.
//  Copyright (c) 2013 Hansul Hudson Jr. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HelloWorldViewController;

@interface HelloWorldAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) HelloWorldViewController *viewController;

@end
