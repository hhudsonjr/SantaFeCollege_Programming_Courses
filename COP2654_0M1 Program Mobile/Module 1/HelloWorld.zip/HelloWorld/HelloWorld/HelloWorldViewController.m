//
//  HelloWorldViewController.m
//  HelloWorld
//
//  Created by Hansul Hudson Jr on 8/26/13.
//  Copyright (c) 2013 Hansul Hudson Jr. All rights reserved.
//

#import "HelloWorldViewController.h"

@interface HelloWorldViewController ()

@end

@implementation HelloWorldViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
