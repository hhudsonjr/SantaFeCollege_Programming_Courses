//
//  main.m
//  HelloWorld
//
//  Created by Hansul Hudson Jr on 8/26/13.
//  Copyright (c) 2013 Hansul Hudson Jr. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HelloWorldAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HelloWorldAppDelegate class]));
    }
}
