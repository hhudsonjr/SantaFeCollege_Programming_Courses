﻿namespace P5hh
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.choosePictureBox = new System.Windows.Forms.PictureBox();
            this.scissorsPictureBox = new System.Windows.Forms.PictureBox();
            this.paperPictureBox = new System.Windows.Forms.PictureBox();
            this.rockPictureBox = new System.Windows.Forms.PictureBox();
            this.computerPictureBox4 = new System.Windows.Forms.PictureBox();
            this.computerPictureBox3 = new System.Windows.Forms.PictureBox();
            this.computerPictureBox2 = new System.Windows.Forms.PictureBox();
            this.computerPictureBox1 = new System.Windows.Forms.PictureBox();
            this.playerPictureBox4 = new System.Windows.Forms.PictureBox();
            this.playerPictureBox3 = new System.Windows.Forms.PictureBox();
            this.playerPictureBox2 = new System.Windows.Forms.PictureBox();
            this.playerPictureBox1 = new System.Windows.Forms.PictureBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.introTextLabel = new System.Windows.Forms.Label();
            this.computerTextLabel = new System.Windows.Forms.Label();
            this.playerTextLabel = new System.Windows.Forms.Label();
            this.winnerTextLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.choosePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rockPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // choosePictureBox
            // 
            this.choosePictureBox.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.choosePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.choosePictureBox.Location = new System.Drawing.Point(167, 67);
            this.choosePictureBox.Name = "choosePictureBox";
            this.choosePictureBox.Size = new System.Drawing.Size(263, 90);
            this.choosePictureBox.TabIndex = 0;
            this.choosePictureBox.TabStop = false;
            // 
            // scissorsPictureBox
            // 
            this.scissorsPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.scissorsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("scissorsPictureBox.Image")));
            this.scissorsPictureBox.Location = new System.Drawing.Point(347, 79);
            this.scissorsPictureBox.Name = "scissorsPictureBox";
            this.scissorsPictureBox.Size = new System.Drawing.Size(64, 65);
            this.scissorsPictureBox.TabIndex = 1;
            this.scissorsPictureBox.TabStop = false;
            this.scissorsPictureBox.Click += new System.EventHandler(this.scissorsPictureBox_Click);
            // 
            // paperPictureBox
            // 
            this.paperPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paperPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("paperPictureBox.Image")));
            this.paperPictureBox.Location = new System.Drawing.Point(266, 79);
            this.paperPictureBox.Name = "paperPictureBox";
            this.paperPictureBox.Size = new System.Drawing.Size(64, 65);
            this.paperPictureBox.TabIndex = 2;
            this.paperPictureBox.TabStop = false;
            this.paperPictureBox.Click += new System.EventHandler(this.paperPictureBox_Click);
            // 
            // rockPictureBox
            // 
            this.rockPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.rockPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("rockPictureBox.Image")));
            this.rockPictureBox.Location = new System.Drawing.Point(186, 79);
            this.rockPictureBox.Name = "rockPictureBox";
            this.rockPictureBox.Size = new System.Drawing.Size(64, 65);
            this.rockPictureBox.TabIndex = 3;
            this.rockPictureBox.TabStop = false;
            this.rockPictureBox.Click += new System.EventHandler(this.rockPictureBox_Click);
            // 
            // computerPictureBox4
            // 
            this.computerPictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("computerPictureBox4.Image")));
            this.computerPictureBox4.Location = new System.Drawing.Point(186, 166);
            this.computerPictureBox4.Name = "computerPictureBox4";
            this.computerPictureBox4.Size = new System.Drawing.Size(64, 65);
            this.computerPictureBox4.TabIndex = 4;
            this.computerPictureBox4.TabStop = false;
            this.computerPictureBox4.Visible = false;
            // 
            // computerPictureBox3
            // 
            this.computerPictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("computerPictureBox3.Image")));
            this.computerPictureBox3.Location = new System.Drawing.Point(186, 166);
            this.computerPictureBox3.Name = "computerPictureBox3";
            this.computerPictureBox3.Size = new System.Drawing.Size(64, 65);
            this.computerPictureBox3.TabIndex = 5;
            this.computerPictureBox3.TabStop = false;
            this.computerPictureBox3.Visible = false;
            // 
            // computerPictureBox2
            // 
            this.computerPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("computerPictureBox2.Image")));
            this.computerPictureBox2.Location = new System.Drawing.Point(186, 166);
            this.computerPictureBox2.Name = "computerPictureBox2";
            this.computerPictureBox2.Size = new System.Drawing.Size(64, 65);
            this.computerPictureBox2.TabIndex = 6;
            this.computerPictureBox2.TabStop = false;
            this.computerPictureBox2.Visible = false;
            // 
            // computerPictureBox1
            // 
            this.computerPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("computerPictureBox1.Image")));
            this.computerPictureBox1.Location = new System.Drawing.Point(186, 166);
            this.computerPictureBox1.Name = "computerPictureBox1";
            this.computerPictureBox1.Size = new System.Drawing.Size(64, 65);
            this.computerPictureBox1.TabIndex = 7;
            this.computerPictureBox1.TabStop = false;
            // 
            // playerPictureBox4
            // 
            this.playerPictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("playerPictureBox4.Image")));
            this.playerPictureBox4.Location = new System.Drawing.Point(347, 166);
            this.playerPictureBox4.Name = "playerPictureBox4";
            this.playerPictureBox4.Size = new System.Drawing.Size(64, 65);
            this.playerPictureBox4.TabIndex = 8;
            this.playerPictureBox4.TabStop = false;
            this.playerPictureBox4.Visible = false;
            // 
            // playerPictureBox3
            // 
            this.playerPictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("playerPictureBox3.Image")));
            this.playerPictureBox3.Location = new System.Drawing.Point(347, 166);
            this.playerPictureBox3.Name = "playerPictureBox3";
            this.playerPictureBox3.Size = new System.Drawing.Size(64, 65);
            this.playerPictureBox3.TabIndex = 9;
            this.playerPictureBox3.TabStop = false;
            this.playerPictureBox3.Visible = false;
            // 
            // playerPictureBox2
            // 
            this.playerPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("playerPictureBox2.Image")));
            this.playerPictureBox2.Location = new System.Drawing.Point(347, 166);
            this.playerPictureBox2.Name = "playerPictureBox2";
            this.playerPictureBox2.Size = new System.Drawing.Size(64, 65);
            this.playerPictureBox2.TabIndex = 10;
            this.playerPictureBox2.TabStop = false;
            this.playerPictureBox2.Visible = false;
            // 
            // playerPictureBox1
            // 
            this.playerPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("playerPictureBox1.Image")));
            this.playerPictureBox1.Location = new System.Drawing.Point(347, 166);
            this.playerPictureBox1.Name = "playerPictureBox1";
            this.playerPictureBox1.Size = new System.Drawing.Size(64, 65);
            this.playerPictureBox1.TabIndex = 11;
            this.playerPictureBox1.TabStop = false;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(266, 372);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 12;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // introTextLabel
            // 
            this.introTextLabel.AutoSize = true;
            this.introTextLabel.Location = new System.Drawing.Point(164, 12);
            this.introTextLabel.Name = "introTextLabel";
            this.introTextLabel.Size = new System.Drawing.Size(286, 52);
            this.introTextLabel.TabIndex = 13;
            this.introTextLabel.Text = "To begin play, make the first move by choosing a selection.\r\nTo make an selection" +
    ", click on an image below. To quit,\r\nselect Exit below.\r\n\r\n";
            // 
            // computerTextLabel
            // 
            this.computerTextLabel.AutoSize = true;
            this.computerTextLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.computerTextLabel.Location = new System.Drawing.Point(116, 234);
            this.computerTextLabel.Name = "computerTextLabel";
            this.computerTextLabel.Size = new System.Drawing.Size(0, 16);
            this.computerTextLabel.TabIndex = 14;
            this.computerTextLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // playerTextLabel
            // 
            this.playerTextLabel.AutoSize = true;
            this.playerTextLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerTextLabel.Location = new System.Drawing.Point(312, 234);
            this.playerTextLabel.Name = "playerTextLabel";
            this.playerTextLabel.Size = new System.Drawing.Size(0, 16);
            this.playerTextLabel.TabIndex = 15;
            this.playerTextLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // winnerTextLabel
            // 
            this.winnerTextLabel.AutoSize = true;
            this.winnerTextLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winnerTextLabel.Location = new System.Drawing.Point(10, 310);
            this.winnerTextLabel.Name = "winnerTextLabel";
            this.winnerTextLabel.Size = new System.Drawing.Size(0, 24);
            this.winnerTextLabel.TabIndex = 16;
            this.winnerTextLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 418);
            this.Controls.Add(this.winnerTextLabel);
            this.Controls.Add(this.playerTextLabel);
            this.Controls.Add(this.computerTextLabel);
            this.Controls.Add(this.introTextLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.playerPictureBox1);
            this.Controls.Add(this.playerPictureBox2);
            this.Controls.Add(this.playerPictureBox3);
            this.Controls.Add(this.playerPictureBox4);
            this.Controls.Add(this.computerPictureBox1);
            this.Controls.Add(this.computerPictureBox2);
            this.Controls.Add(this.computerPictureBox3);
            this.Controls.Add(this.computerPictureBox4);
            this.Controls.Add(this.rockPictureBox);
            this.Controls.Add(this.paperPictureBox);
            this.Controls.Add(this.scissorsPictureBox);
            this.Controls.Add(this.choosePictureBox);
            this.Name = "Form1";
            this.Text = "Rocks Paper Scissors";
            ((System.ComponentModel.ISupportInitialize)(this.choosePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rockPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox choosePictureBox;
        private System.Windows.Forms.PictureBox scissorsPictureBox;
        private System.Windows.Forms.PictureBox paperPictureBox;
        private System.Windows.Forms.PictureBox rockPictureBox;
        private System.Windows.Forms.PictureBox computerPictureBox4;
        private System.Windows.Forms.PictureBox computerPictureBox3;
        private System.Windows.Forms.PictureBox computerPictureBox2;
        private System.Windows.Forms.PictureBox computerPictureBox1;
        private System.Windows.Forms.PictureBox playerPictureBox4;
        private System.Windows.Forms.PictureBox playerPictureBox3;
        private System.Windows.Forms.PictureBox playerPictureBox2;
        private System.Windows.Forms.PictureBox playerPictureBox1;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label introTextLabel;
        private System.Windows.Forms.Label computerTextLabel;
        private System.Windows.Forms.Label playerTextLabel;
        private System.Windows.Forms.Label winnerTextLabel;
    }
}

