﻿namespace P2hh
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.capA_Button = new System.Windows.Forms.Button();
            this.a_Button = new System.Windows.Forms.Button();
            this.capAn_Button = new System.Windows.Forms.Button();
            this.an_Button = new System.Windows.Forms.Button();
            this.capThe_Button = new System.Windows.Forms.Button();
            this.the_Button = new System.Windows.Forms.Button();
            this.man_Button = new System.Windows.Forms.Button();
            this.woman_Button = new System.Windows.Forms.Button();
            this.dog_Button = new System.Windows.Forms.Button();
            this.cat_Button = new System.Windows.Forms.Button();
            this.car_Button = new System.Windows.Forms.Button();
            this.bicycle_Button = new System.Windows.Forms.Button();
            this.beautiful_Button = new System.Windows.Forms.Button();
            this.big_Button = new System.Windows.Forms.Button();
            this.small_Button = new System.Windows.Forms.Button();
            this.strange_Button = new System.Windows.Forms.Button();
            this.lookedAt_Button = new System.Windows.Forms.Button();
            this.rode_Button = new System.Windows.Forms.Button();
            this.spokeTo_Button = new System.Windows.Forms.Button();
            this.laughedAt_Button = new System.Windows.Forms.Button();
            this.drove_Button = new System.Windows.Forms.Button();
            this.space_Button = new System.Windows.Forms.Button();
            this.period_Button = new System.Windows.Forms.Button();
            this.exclamation_Button = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.sentenceDisplayLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // capA_Button
            // 
            this.capA_Button.Location = new System.Drawing.Point(94, 12);
            this.capA_Button.Name = "capA_Button";
            this.capA_Button.Size = new System.Drawing.Size(34, 23);
            this.capA_Button.TabIndex = 0;
            this.capA_Button.Text = "A";
            this.capA_Button.UseVisualStyleBackColor = true;
            this.capA_Button.Click += new System.EventHandler(this.capA_Button_Click);
            // 
            // a_Button
            // 
            this.a_Button.Location = new System.Drawing.Point(134, 12);
            this.a_Button.Name = "a_Button";
            this.a_Button.Size = new System.Drawing.Size(34, 23);
            this.a_Button.TabIndex = 1;
            this.a_Button.Text = "a";
            this.a_Button.UseVisualStyleBackColor = true;
            this.a_Button.Click += new System.EventHandler(this.a_Button_Click);
            // 
            // capAn_Button
            // 
            this.capAn_Button.Location = new System.Drawing.Point(174, 12);
            this.capAn_Button.Name = "capAn_Button";
            this.capAn_Button.Size = new System.Drawing.Size(45, 23);
            this.capAn_Button.TabIndex = 2;
            this.capAn_Button.Text = "An";
            this.capAn_Button.UseVisualStyleBackColor = true;
            this.capAn_Button.Click += new System.EventHandler(this.capAn_Button_Click);
            // 
            // an_Button
            // 
            this.an_Button.Location = new System.Drawing.Point(225, 12);
            this.an_Button.Name = "an_Button";
            this.an_Button.Size = new System.Drawing.Size(45, 23);
            this.an_Button.TabIndex = 3;
            this.an_Button.Text = "an";
            this.an_Button.UseVisualStyleBackColor = true;
            this.an_Button.Click += new System.EventHandler(this.an_Button_Click);
            // 
            // capThe_Button
            // 
            this.capThe_Button.Location = new System.Drawing.Point(276, 12);
            this.capThe_Button.Name = "capThe_Button";
            this.capThe_Button.Size = new System.Drawing.Size(45, 23);
            this.capThe_Button.TabIndex = 4;
            this.capThe_Button.Text = "The";
            this.capThe_Button.UseVisualStyleBackColor = true;
            this.capThe_Button.Click += new System.EventHandler(this.capThe_Button_Click);
            // 
            // the_Button
            // 
            this.the_Button.Location = new System.Drawing.Point(327, 12);
            this.the_Button.Name = "the_Button";
            this.the_Button.Size = new System.Drawing.Size(45, 23);
            this.the_Button.TabIndex = 5;
            this.the_Button.Text = "the";
            this.the_Button.UseVisualStyleBackColor = true;
            this.the_Button.Click += new System.EventHandler(this.the_Button_Click);
            // 
            // man_Button
            // 
            this.man_Button.Location = new System.Drawing.Point(74, 41);
            this.man_Button.Name = "man_Button";
            this.man_Button.Size = new System.Drawing.Size(45, 23);
            this.man_Button.TabIndex = 6;
            this.man_Button.Text = "man";
            this.man_Button.UseVisualStyleBackColor = true;
            this.man_Button.Click += new System.EventHandler(this.man_Button_Click);
            // 
            // woman_Button
            // 
            this.woman_Button.Location = new System.Drawing.Point(125, 41);
            this.woman_Button.Name = "woman_Button";
            this.woman_Button.Size = new System.Drawing.Size(63, 23);
            this.woman_Button.TabIndex = 7;
            this.woman_Button.Text = "woman";
            this.woman_Button.UseVisualStyleBackColor = true;
            this.woman_Button.Click += new System.EventHandler(this.woman_Button_Click);
            // 
            // dog_Button
            // 
            this.dog_Button.Location = new System.Drawing.Point(194, 41);
            this.dog_Button.Name = "dog_Button";
            this.dog_Button.Size = new System.Drawing.Size(45, 23);
            this.dog_Button.TabIndex = 8;
            this.dog_Button.Text = "dog";
            this.dog_Button.UseVisualStyleBackColor = true;
            this.dog_Button.Click += new System.EventHandler(this.dog_Button_Click);
            // 
            // cat_Button
            // 
            this.cat_Button.Location = new System.Drawing.Point(245, 41);
            this.cat_Button.Name = "cat_Button";
            this.cat_Button.Size = new System.Drawing.Size(45, 23);
            this.cat_Button.TabIndex = 9;
            this.cat_Button.Text = "cat";
            this.cat_Button.UseVisualStyleBackColor = true;
            this.cat_Button.Click += new System.EventHandler(this.cat_Button_Click);
            // 
            // car_Button
            // 
            this.car_Button.Location = new System.Drawing.Point(296, 41);
            this.car_Button.Name = "car_Button";
            this.car_Button.Size = new System.Drawing.Size(45, 23);
            this.car_Button.TabIndex = 10;
            this.car_Button.Text = "car";
            this.car_Button.UseVisualStyleBackColor = true;
            this.car_Button.Click += new System.EventHandler(this.car_Button_Click);
            // 
            // bicycle_Button
            // 
            this.bicycle_Button.Location = new System.Drawing.Point(347, 41);
            this.bicycle_Button.Name = "bicycle_Button";
            this.bicycle_Button.Size = new System.Drawing.Size(63, 23);
            this.bicycle_Button.TabIndex = 11;
            this.bicycle_Button.Text = "bicycle";
            this.bicycle_Button.UseVisualStyleBackColor = true;
            this.bicycle_Button.Click += new System.EventHandler(this.bicycle_Button_Click);
            // 
            // beautiful_Button
            // 
            this.beautiful_Button.Location = new System.Drawing.Point(105, 70);
            this.beautiful_Button.Name = "beautiful_Button";
            this.beautiful_Button.Size = new System.Drawing.Size(63, 23);
            this.beautiful_Button.TabIndex = 12;
            this.beautiful_Button.Text = "beautiful";
            this.beautiful_Button.UseVisualStyleBackColor = true;
            this.beautiful_Button.Click += new System.EventHandler(this.beautiful_Button_Click);
            // 
            // big_Button
            // 
            this.big_Button.Location = new System.Drawing.Point(174, 70);
            this.big_Button.Name = "big_Button";
            this.big_Button.Size = new System.Drawing.Size(45, 23);
            this.big_Button.TabIndex = 13;
            this.big_Button.Text = "big";
            this.big_Button.UseVisualStyleBackColor = true;
            this.big_Button.Click += new System.EventHandler(this.big_Button_Click);
            // 
            // small_Button
            // 
            this.small_Button.Location = new System.Drawing.Point(225, 70);
            this.small_Button.Name = "small_Button";
            this.small_Button.Size = new System.Drawing.Size(75, 23);
            this.small_Button.TabIndex = 14;
            this.small_Button.Text = "small";
            this.small_Button.UseVisualStyleBackColor = true;
            this.small_Button.Click += new System.EventHandler(this.small_Button_Click);
            // 
            // strange_Button
            // 
            this.strange_Button.Location = new System.Drawing.Point(306, 70);
            this.strange_Button.Name = "strange_Button";
            this.strange_Button.Size = new System.Drawing.Size(63, 23);
            this.strange_Button.TabIndex = 15;
            this.strange_Button.Text = "strange";
            this.strange_Button.UseVisualStyleBackColor = true;
            this.strange_Button.Click += new System.EventHandler(this.strange_Button_Click);
            // 
            // lookedAt_Button
            // 
            this.lookedAt_Button.Location = new System.Drawing.Point(73, 99);
            this.lookedAt_Button.Name = "lookedAt_Button";
            this.lookedAt_Button.Size = new System.Drawing.Size(75, 23);
            this.lookedAt_Button.TabIndex = 16;
            this.lookedAt_Button.Text = "looked at";
            this.lookedAt_Button.UseVisualStyleBackColor = true;
            this.lookedAt_Button.Click += new System.EventHandler(this.lookedAt_Button_Click);
            // 
            // rode_Button
            // 
            this.rode_Button.Location = new System.Drawing.Point(154, 99);
            this.rode_Button.Name = "rode_Button";
            this.rode_Button.Size = new System.Drawing.Size(50, 23);
            this.rode_Button.TabIndex = 17;
            this.rode_Button.Text = "rode";
            this.rode_Button.UseVisualStyleBackColor = true;
            this.rode_Button.Click += new System.EventHandler(this.rode_Button_Click);
            // 
            // spokeTo_Button
            // 
            this.spokeTo_Button.Location = new System.Drawing.Point(210, 99);
            this.spokeTo_Button.Name = "spokeTo_Button";
            this.spokeTo_Button.Size = new System.Drawing.Size(60, 23);
            this.spokeTo_Button.TabIndex = 18;
            this.spokeTo_Button.Text = "spoke to";
            this.spokeTo_Button.UseVisualStyleBackColor = true;
            this.spokeTo_Button.Click += new System.EventHandler(this.spokeTo_Button_Click);
            // 
            // laughedAt_Button
            // 
            this.laughedAt_Button.Location = new System.Drawing.Point(276, 99);
            this.laughedAt_Button.Name = "laughedAt_Button";
            this.laughedAt_Button.Size = new System.Drawing.Size(75, 23);
            this.laughedAt_Button.TabIndex = 19;
            this.laughedAt_Button.Text = "laughed at";
            this.laughedAt_Button.UseVisualStyleBackColor = true;
            this.laughedAt_Button.Click += new System.EventHandler(this.laughedAt_Button_Click);
            // 
            // drove_Button
            // 
            this.drove_Button.Location = new System.Drawing.Point(357, 99);
            this.drove_Button.Name = "drove_Button";
            this.drove_Button.Size = new System.Drawing.Size(51, 23);
            this.drove_Button.TabIndex = 20;
            this.drove_Button.Text = "drove";
            this.drove_Button.UseVisualStyleBackColor = true;
            this.drove_Button.Click += new System.EventHandler(this.drove_Button_Click);
            // 
            // space_Button
            // 
            this.space_Button.Location = new System.Drawing.Point(179, 128);
            this.space_Button.Name = "space_Button";
            this.space_Button.Size = new System.Drawing.Size(75, 23);
            this.space_Button.TabIndex = 21;
            this.space_Button.Text = "(Space)";
            this.space_Button.UseVisualStyleBackColor = true;
            this.space_Button.Click += new System.EventHandler(this.space_Button_Click);
            // 
            // period_Button
            // 
            this.period_Button.Location = new System.Drawing.Point(260, 128);
            this.period_Button.Name = "period_Button";
            this.period_Button.Size = new System.Drawing.Size(30, 23);
            this.period_Button.TabIndex = 22;
            this.period_Button.Text = ".";
            this.period_Button.UseVisualStyleBackColor = true;
            this.period_Button.Click += new System.EventHandler(this.period_Button_Click);
            // 
            // exclamation_Button
            // 
            this.exclamation_Button.Location = new System.Drawing.Point(296, 128);
            this.exclamation_Button.Name = "exclamation_Button";
            this.exclamation_Button.Size = new System.Drawing.Size(30, 23);
            this.exclamation_Button.TabIndex = 23;
            this.exclamation_Button.Text = "!";
            this.exclamation_Button.UseVisualStyleBackColor = true;
            this.exclamation_Button.Click += new System.EventHandler(this.exclamation_Button_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(170, 209);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 24;
            this.resetButton.Text = "Clear";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(251, 209);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 25;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // sentenceDisplayLabel
            // 
            this.sentenceDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sentenceDisplayLabel.Location = new System.Drawing.Point(12, 164);
            this.sentenceDisplayLabel.Name = "sentenceDisplayLabel";
            this.sentenceDisplayLabel.Size = new System.Drawing.Size(457, 23);
            this.sentenceDisplayLabel.TabIndex = 26;
            this.sentenceDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.sentenceDisplayLabel.Click += new System.EventHandler(this.sentenceDisplayLabel_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 248);
            this.Controls.Add(this.sentenceDisplayLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.exclamation_Button);
            this.Controls.Add(this.period_Button);
            this.Controls.Add(this.space_Button);
            this.Controls.Add(this.drove_Button);
            this.Controls.Add(this.laughedAt_Button);
            this.Controls.Add(this.spokeTo_Button);
            this.Controls.Add(this.rode_Button);
            this.Controls.Add(this.lookedAt_Button);
            this.Controls.Add(this.strange_Button);
            this.Controls.Add(this.small_Button);
            this.Controls.Add(this.big_Button);
            this.Controls.Add(this.beautiful_Button);
            this.Controls.Add(this.bicycle_Button);
            this.Controls.Add(this.car_Button);
            this.Controls.Add(this.cat_Button);
            this.Controls.Add(this.dog_Button);
            this.Controls.Add(this.woman_Button);
            this.Controls.Add(this.man_Button);
            this.Controls.Add(this.the_Button);
            this.Controls.Add(this.capThe_Button);
            this.Controls.Add(this.an_Button);
            this.Controls.Add(this.capAn_Button);
            this.Controls.Add(this.a_Button);
            this.Controls.Add(this.capA_Button);
            this.Name = "Form1";
            this.Text = "The Sentence Builder";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button capA_Button;
        private System.Windows.Forms.Button a_Button;
        private System.Windows.Forms.Button capAn_Button;
        private System.Windows.Forms.Button an_Button;
        private System.Windows.Forms.Button capThe_Button;
        private System.Windows.Forms.Button the_Button;
        private System.Windows.Forms.Button man_Button;
        private System.Windows.Forms.Button woman_Button;
        private System.Windows.Forms.Button dog_Button;
        private System.Windows.Forms.Button cat_Button;
        private System.Windows.Forms.Button car_Button;
        private System.Windows.Forms.Button bicycle_Button;
        private System.Windows.Forms.Button beautiful_Button;
        private System.Windows.Forms.Button big_Button;
        private System.Windows.Forms.Button small_Button;
        private System.Windows.Forms.Button strange_Button;
        private System.Windows.Forms.Button lookedAt_Button;
        private System.Windows.Forms.Button rode_Button;
        private System.Windows.Forms.Button spokeTo_Button;
        private System.Windows.Forms.Button laughedAt_Button;
        private System.Windows.Forms.Button drove_Button;
        private System.Windows.Forms.Button space_Button;
        private System.Windows.Forms.Button period_Button;
        private System.Windows.Forms.Button exclamation_Button;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label sentenceDisplayLabel;
    }
}

