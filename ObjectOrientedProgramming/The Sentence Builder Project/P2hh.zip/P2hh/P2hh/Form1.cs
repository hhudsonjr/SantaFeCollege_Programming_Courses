﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P2hh
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void capA_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " A";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
            
        }

        private void a_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " a";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;

        }

        private void sentenceDisplayLabel_Click(object sender, EventArgs e)
        {
           
        }

        private void capAn_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " An";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void an_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " an";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void capThe_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " The";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void the_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " the";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void man_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " man";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void woman_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " woman";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void dog_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " dog";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void cat_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " cat";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void car_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " car";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void bicycle_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " bicycle";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void beautiful_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " beautiful";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void big_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " big";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void small_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " small";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void strange_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " strange";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void lookedAt_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " looked at";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void rode_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " rode";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void spokeTo_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " spoke to";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void laughedAt_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " laughed at";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void drove_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " drove";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void space_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = " ";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void period_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = ".";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void exclamation_Button_Click(object sender, EventArgs e)
        {
            // Declare a string variable.
            string word = "!";

            // Declare another string variable.
            string output;

            // Assign a value to a string variable
            output = word;

            // Disply the output.
            sentenceDisplayLabel.Text = sentenceDisplayLabel.Text + word;
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            sentenceDisplayLabel.Text = " ";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
